# header 1
## Header 2
### Header 3     
#### Header 4

    <xml>somexml</xml>
    
``` java
 Somejava s = new SomeJava();
```
 
> **Note**
>
> This is a Note



> **Warning**
>
> This is a warning

`literal`
